

from telethon import TelegramClient
#
# #=======================================================================
# +12345678911
api_id =1163316
api_hash = '8be3296f883d7bfd51472f4b7e6d3f7e'
client1 = TelegramClient('+13821290771.session', api_id, api_hash)
# client1.start(password='Wfl123456.')
client1.start()
# #===============================================================

#客户列表。需要手动添加
client_list = []
client_list.append(client1)