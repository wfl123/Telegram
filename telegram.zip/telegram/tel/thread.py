# #!/usr/bin/env python
# # -*- coding:utf-8 -*-
# #@Time  : 2019/9/13 17:24
# #@Author: weifulong
# #@File  : thread.py
# import random
# import threading
# from queue import Queue
# import time
# import sys
# import time
# from telethon import TelegramClient
# from telethon import TelegramClient, sync,events
#
#
# # ==============    +8619965041445   ==================
# api_id = 1068342
# api_hash = '42a3c005195125361dd39c38f85946bb'
# client = TelegramClient('F:\python_station\\telegram\\tel\8619965041445.session', api_id, api_hash)
#
# async def task():
#     aleikeji =await client.get_entity(-1001172149960)
#     message_result = []  # 存放创建者
#     # 获取频道全部信息
#
#     count = 1
#     startTime = time.time()
#     async for mess in client.iter_messages(aleikeji, limit=1000):
#         count += 1
#         message_result.append(str(mess.message)+'\n')
#         print(count,aleikeji.title)
#     print('总耗时--->', time.time() - startTime)
#     # async for dialog in client.iter_dialogs():
#     #     print(dialog.id,'--->',dialog.name)
# with client:
#     client.loop.run_until_complete(task())

#!/usr/bin/env python
# -*- coding:utf-8 -*-
#@Time  : 2019/9/13 20:26
#@Author: weifulong
#@File  : thread11.py
import random
import threading
from queue import Queue
import time
import sys
import time
from telethon import TelegramClient
from telethon import TelegramClient, sync,events

import time
import asyncio
import threading
# ==============   +8615303517524    ===================
from telethon.tl.types import PeerChannel

api_id = 1188540
api_hash = 'f7fa2a4d485d3e1cb2177e74a2286589'
client = TelegramClient('8615303517524.session', api_id, api_hash)
aleikeji = ''#client.get_entity(-1001172149960)
anwang =''# client.get_entity(-1001185959795)
qurey1=Queue()
qurey2=Queue()
# qurey3=Queue()
# qurey4=Queue()
# qurey5=Queue()
# qurey6=Queue()
# qurey7=Queue()
# qurey8=Queue()
# qurey9=Queue()
# qurey10=Queue()

async def task(l,q,client111):

    message_result = ''  # 存放创建者
    # 获取频道全部信息
    count = 1
    startTime = time.time()
    async for mess in client.iter_messages(client111, limit=300):
        count += 1
        message_result+=str( mess.message)
        message_result+="\n==================\n"
        # print(count,client111.title)
    q.put(message_result)
    print('总耗时--->', time.time() - startTime)
# async def task1(client111):
#
#     print(client111)

def thread(loop,cli,query):  # 异步程序
    asyncio.set_event_loop(loop)
    # asyncio.ensure_future(task('sub thread',qurey1, aleikeji))
    # loop.run_forever()
    loop.run_until_complete(task('sub thread',query, cli))
#
# def thread1(loop,cli):  # 异步程序
#     asyncio.set_event_loop(loop)
#     # asyncio.ensure_future(task('sub thread',qurey1, aleikeji))
#     # loop.run_forever()
#     loop.run_until_complete(task('sub thread',qurey2, cli))

def main():
    aleikeji = client.get_entity(PeerChannel(1274378470))
    anwang = client.get_entity(PeerChannel(1393167448))
    huichan = client.get_entity(PeerChannel(1336107536))
    threading.Thread(target=thread, args=(asyncio.get_event_loop(),anwang,qurey1 )).start()
    threading.Thread(target=thread, args=(asyncio.get_event_loop(),aleikeji,qurey1 )).start()
    # thread1=threading.Thread(target=thread, args=(asyncio.get_event_loop(),anwang,qurey1 ))
    # thread2=threading.Thread(target=thread, args=(asyncio.get_event_loop(),aleikeji,qurey2 ))
    # thread1.start()
    # thread2.start()

    # thread1.join()
    # thread2.join()
    try:
        # 同步代码开始
        future = asyncio.ensure_future(task('main thread',qurey2, huichan))
        # future2 = asyncio.ensure_future(task('main thread',qurey1, aleikeji))
        # future = asyncio.ensure_future(task1( aleikeji))
        # future2 = asyncio.ensure_future(task('main thread',qurey1, anwang))
        while not future.done():
            time.sleep(1)
        print('aleikeji done: %s' % future.result())
        # future.cancelled()
    except Exception as e :
        print(e.args)
    with open('E:\\quer2.txt','w+',encoding='utf-8') as f:
        f.write(qurey2.get())
    # print(qurey2.get())
    # while not future2.done():
    #     time.sleep(1)
    # print('anwang done: %s' % future.result())

if __name__=='__main__':
    with client:
        client.loop.run_until_complete(main())