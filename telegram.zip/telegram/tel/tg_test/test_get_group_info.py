#!/usr/bin/env python
# -*- coding:utf-8 -*-
#@Time  : 2019/9/12 9:57
#@Author: weifulong
#@File  : test2.py
#coding=utf-8
import datetime
import os
import re
import time

import socks
from telethon import TelegramClient
from telethon.tl import functions
from telethon.tl.functions.messages import GetHistoryRequest
from telethon.tl.types import PeerUser, PeerChat, PeerChannel, ChannelParticipantsAdmins

# from tel.tg_final import config
# import tg_final.config



# Use your own values from my.telegram.org
# ==============    +8619965041445   ==================
# api_id = 1068342
# api_hash = '42a3c005195125361dd39c38f85946bb'
# client = TelegramClient('D:\pystation\\telegram\\telegram\\tel\\123.session', api_id, api_hash)
#=================    +8617344494726   ============
# api_id = 1061692
# api_hash = '10249070637ca3240d5553210fcee4d8'
# client = TelegramClient('8617344494726.session', api_id, api_hash)

# ==============   +19146628720    ===================
# api_id = 1070525
# api_hash = '5546d878a15d86a4a34c93eaa848684d'
# client = TelegramClient('19146628720.session', api_id, api_hash)

# # ==============   +8615303517524    ===================
api_id = 1188540
api_hash = 'f7fa2a4d485d3e1cb2177e74a2286589'
client = TelegramClient('8615303517524.session', api_id, api_hash)
#  +17726754715
# api_id = 1042049
# api_hash = 'eb2c376a6f7af441ec37369027806551'
# client =TelegramClient('session_id',
#     api_id=api_id, api_hash=api_hash
# )
client.start(password='w19980328')
# #  +17726184063
# api_id = 1080743
# api_hash = 'aba6a48f44f7bf7725984bcdb6e941bc'
# client =TelegramClient('session_id',
#     api_id=api_id, api_hash=api_hash
# )
# client =TelegramClient('session_id',
#     api_id=api_id, api_hash=api_hash,
#     proxy=(socks.SOCKS5, 'localhost', 4444)
# )

# 获取频道信息，名称，id 判断是否为channel   使用频道信息的 broadcast参数
async def main():
    import getpass
    from telethon.errors import SessionPasswordNeededError
    # client.connect()
    # print(client.is_user_authorized())
    print(00000000)
    async for g in client.iter_dialogs():
        print(g.stringify())
    # TelegramClient.sign_in('+17726184063')
    try:
        print(111111111)
        # TelegramClient.sign_in(code=input('Enter code: '))
        print(222222222)
    except SessionPasswordNeededError:
        print(33333333)
        TelegramClient.sign_in(password=getpass.getpass())
    # entity = await client.get_entity(PeerChannel(1393167448))
    # entity1 = await client.get_entity(1393167448)
    ##################
    # result =await client(functions.messages.ReadHistoryRequest(
    #     peer=await client.get_entity(PeerChannel(1393167448)),
    #     max_id=1000
    # ))
    # print(result.stringify())
    ###################
    # result =await client(functions.messages.GetHistoryRequest(
    #     peer=entity,
    #     offset_id=42,
    #     offset_date=datetime.datetime(2019, 6, 25),
    #     add_offset=0,
    #     limit=100,
    #     max_id=0,
    #     min_id=0,
    #     hash=0
    # ))
    # print(result.stringify())
    #####################
    # for msg in await client.get_messages(entity,offset_date=datetime.date(2019, 11, 4)):
    # for i in range(116370,116386):
    # for msg in :
    # async for msg in client.iter_messages(entity,offset_date=datetime.datetime(2019, 6, 2, 3, 38, 35, tzinfo=datetime.timezone.utc)):
    #     print(msg )


    # start_time = time.time()
    # result =await client(functions.users.GetFullUserRequest(
    #     id=int("{}".format(868233967))
    # ))
    # print("11111>",time.time()-start_time)
    # # print(result.user.first_name)
    # # print(result.user.last_name)
    # # print(result.user.username)
    # # print(result.user.phone)
    # # print(result.common_chats_count)
    # st_time = time.time()
    # print(await client.get_entity(PeerUser(708230468)))
    # print("22222222>",time.time()-start_time)
    # start_time = time.time()
    # result =await client(functions.contacts.ResolveUsernameRequest(
    #     username='708230468')
    # )
    # print(result.stringify())
    # print("33333333>",time.time()-start_time)
    # print(await client.get_entity(800559684))
    # result =await client(functions.messages.GetHistoryRequest(
    #     peer=entity,
    #     offset_id=42,
    #     offset_date=datetime.datetime(2018, 6, 25),
    #     add_offset=0,
    #     limit=100,
    #     max_id=0,
    #     min_id=0,
    #     hash=0
    # ))
    # print(result.stringify())

    # =================

    # ==================
#     ExportAuthorizationRequest
#     sent =await client(functions.auth.SignInRequest(
#         phone_number='+8613821290779',
#         phone_code_hash='fdscsdfdsfcsdczxcs',
#         phone_code='400460'
#     ))
#     print(sent)
    # print(result)
# ================自动添加去群组====================
#     from telethon.tl.functions.messages import ImportChatInviteRequest
#     updates = await client(ImportChatInviteRequest('OK96uxc9H4zE36GntvPx3g'))
#     print(updates.stringfy())
# =======================进入、离开群组获取信息============
        # @client.on(events.ChatAction)
        #     async def handle(event):
        #         if event.user_left or event.user_joined:
        #             print('1',await event.get_user())

# ==================添加===========
# from telethon.sync import TelegramClient
# from telethon import functions, types
#
# with TelegramClient(name, api_id, api_hash) as client:
#     result = client(functions.channels.GetFullChannelRequest(
#         channel='username'
#     ))
#     print(result.stringify())

with client:
    # client.start(password='w19980328')
    client.loop.run_until_complete(main())
    # pass