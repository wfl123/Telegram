#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @Time  : 2019/9/12 9:57
# @Author: weifulong
# @File  : test2.py
# coding=utf-8
import json
from telethon import TelegramClient
from telethon.tl.types import ChannelParticipantsAdmins, PeerChannel

from tel.tg_final import client_config

# api_id = 1188540
# api_hash = 'f7fa2a4d485d3e1cb2177e74a2286589'
# client = TelegramClient('8615303517524.session', api_id, api_hash)
# client = ' '
async def main1():
    print('111111')
def main():
    for clitn_i in client_config.client_list:
        client = clitn_i
        # async for u in client.get_dialogs():
        #     print(u)
        # with client:
        print(client)
        #     client.loop.run_until_complete(main())
        with client:
            client.loop.run_until_complete(main1())
main()