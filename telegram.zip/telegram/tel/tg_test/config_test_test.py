from tel.tg_final import client_config
from tel.tg_final import config_final

config_final.run(client_config.client_list2)

