#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @Time  : 2019/9/12 9:57
# @Author: weifulong
# @File  : test2.py
# coding=utf-8
import json


from tel.tg_final import config


api_id = config.api_id
api_hash = config.api_hash
client = config.client

async def main():
    from telethon.sync import TelegramClient
    from telethon import functions, types

    result11 =await client( functions.messages.CheckChatInviteRequest(hash='A4LmkR23G0IGxBE71zZfo1'))
    print(result11.stringify())


with client:
    client.loop.run_until_complete(main())