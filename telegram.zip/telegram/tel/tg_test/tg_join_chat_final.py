#!/usr/bin/env python
# -*- coding:utf-8 -*-
#@Time  : 2019/9/12 9:57
#@Author: weifulong
#@File  : test2.py
#coding=utf-8
from telethon import TelegramClient
from telethon import TelegramClient, sync,events
import logging
import random
import datetime
import asyncio
import telethon
from telethon.tl.types import PeerUser, PeerChat, PeerChannel,UpdateNewChannelMessage
from telethon.tl.functions.messages import SendMessageRequest, GetHistoryRequest
from telethon.tl import types, functions
from telethon import utils
from telethon.tl.functions.channels import GetParticipantsRequest
from telethon.tl.types import ChannelParticipantsSearch
from time import sleep

from tel.tg_final import config


api_id = config.api_id
api_hash = config.api_hash
client = config.client
# 获取频道信息，名称，id 判断是否为channel   使用频道信息的 broadcast参数
async def main():
    from telethon.tl.functions.channels import JoinChannelRequest
    try:
        channel_id = '1187572383'
        #根据id 添加公开群组group 添加公开频道channel
        channel = await client.get_entity(PeerChannel(int('{channel_id}'.format(channel_id=channel_id))))
        await client(JoinChannelRequest(channel))
    except Exception as e:
        print(e.args)
        pass
    #添加私人链接群组 https://t.me/joinchat/AAAAAFFszQPyPEZ7wgxLtd
    # from telethon.tl.functions.messages import ImportChatInviteRequest
    # updates = await client(ImportChatInviteRequest('AAAAAEHbEkejzxUjAUCfYg'))

with client:
    client.loop.run_until_complete(main())