#!/usr/bin/env python
# -*- coding:utf-8 -*-
#@Time  : 2019/9/15 15:44
#@Author: weifulong
#@File  : get_full_admin_info.py

#获取管理员信息
import time
from datetime import date

from telethon import TelegramClient, sync,events


# ==============    +8619965041445   ==================
api_id = 1068342
api_hash = '42a3c005195125361dd39c38f85946bb'
client = TelegramClient('123.session', api_id, api_hash)
#=================    +8617344494726   ============
# api_id = 1061692D
# api_hash = '10249070637ca3240d5553210fcee4d8'
# client = TelegramClient('D:\python_station\\telegram\\tel\8617344494726.session', api_id, api_hash)
# ==============   +8615303517524    ===================
# api_id = 1188540
# api_hash = 'f7fa2a4d485d3e1cb2177e74a2286589'
# client = TelegramClient('D:\python_station\\telegram\\tel\8615303517524.session', api_id, api_hash)

today=date.today()
# # today='2019-09-15'
# # 获取频道信息，名称，id
# async def get_channel_info():
#     async for dialog in client.iter_dialogs():
#         print('{:>14}: {}'.format(dialog.id, dialog.entity.id))
#         # print(dialog.stringify())
#         try:
#             if dialog.entity.broadcast == 'True':
#                 dialog.entity.broadcast = '群组'
#         except:
#             #if dialog.entity.broadcast == 'True':
#                 dialog.entity.broadcast = ' '
#         try:
#             with  open("E:\电报\群组信息\{}_群.txt".format(today),'a+',encoding='utf-8') as f:
#                 f.write(str(dialog.title))
#                 f.write(' ---> ')
#                 f.write(str(dialog.entity.id))
#                 f.write(' ---> t.me/')
#                 try:
#                     f.write(str(dialog.entity.username))
#                 except:
#                     dialog.entity.username=' '
#                     f.write(str(dialog.entity.username))
#                 f.write(' ---> ')
#                 f.write(str(dialog.entity.broadcast))
#                 f.write('\n')
#                 print(123)
#         except:
#             pass


# ===============获取admin========
from telethon.tl.types import ChannelParticipantsAdmins
async def get_admin():
    # await get_channel_info()
    with  open("E:\电报\群组信息\{}_群.txt".format(today), 'r', encoding='utf-8') as f:
        for line in f.readlines():

            group_name=str(line).split(' ---> ')[0]
            #管理员
            print(group_name)
            try:
                async for user in client.iter_participants('{}'.format(group_name),filter=ChannelParticipantsAdmins,aggressive='True'):
                # async for user in client.iter_participants('阿雷科技'):
                #     with open("E:\电报\群组信息\{}管理员信息.txt".format(group_name),'a+',encoding='utf-8') as f:
                #         user_result='ID:'+str(user.id)+' ---> '+str(user.first_name)+'--->'+str(user.last_name)+'--->'+str(user.username)+'--->'+str(user.phone)+'\n'
                #         f.write(user_result)
                    print(user.stringify())
                time.sleep(20)
            except:
                pass
from telethon.sync import TelegramClient


with client:
    client.loop.run_until_complete(get_admin())
    # client.loop.run_until_complete(get_channel_info())