# #!/usr/bin/env python
# # -*- coding:utf-8 -*-
# #@Time  : 2019/9/13 17:24
# #@Author: weifulong
# #@File  : thread.py
import json
import random
import threading
from queue import Queue
import time
import sys
import time
from telethon import TelegramClient
from telethon import TelegramClient, sync,events

import time
import asyncio
from datetime import datetime, timedelta, timezone
import threading
# ==============   +8615303517524    ===================
from telethon.tl import functions
from telethon.tl.types import PeerChannel

api_id = 1188540
api_hash = 'f7fa2a4d485d3e1cb2177e74a2286589'
client = TelegramClient('8615303517524.session', api_id, api_hash)

aleikeji = ''#client.get_entity(-1001172149960)
anwang =''# client.get_entity(-1001185959795)
qurey1=Queue()
qurey2=Queue()


# async def task(l,q,client111):
#
#     message_result = ''  # 存放创建者
#     # 获取频道全部信息
#     count = 1
#     startTime = time.time()
#     async for mess in client.iter_messages(client111, limit=300):
#         count += 1
#         message_result+=str( mess.message)
#         message_result+="\n==================\n"
#         # print(count,client111.title)
#     q.put(message_result)
#     print('总耗时--->', time.time() - startTime)
async def task(client,msg_num,file_local,channel_id):

    client = client

    result = []
    from telethon.tl.types import PeerUser, PeerChat, PeerChannel
    channel_id = channel_id
    # channel_id = '1172149960'
    # 两种id 均可以
    entity = await client.get_entity(PeerChannel(int ('{channel_id}'.format(channel_id=channel_id))))
    async for message in client.iter_messages(entity,wait_time=1,limit=msg_num):
        temp_dict = {}
        try:
            message_media_id = message.media.id
        except:
            message_media_id = ' '
        try:
            message_medis_photo_id = message.medis.photo.id
        except:
            message_medis_photo_id = ' '
        try:
            message_media_document_id = message.media.document.id
        except:
            message_media_document_id = ' '
        try:

            temp_dict['信息内容：'] = str(message.message)
            temp_dict['发信息时间：'] = str(message.date.replace(tzinfo=timezone.utc).astimezone(timezone(timedelta(hours=8))))
            temp_dict['发言者ID：'] = str(message.from_id)
            #获取发言者信息
            try:
                result_msg = await client(functions.users.GetFullUserRequest(id=int("{}".format(str(message.from_id)))))
                temp_dict['发言者first_name：'] = str(result_msg.user.first_name)
                temp_dict['发言者last_name ：'] = str(result_msg.user.last_name)
                temp_dict['发言者username ：'] = str(result_msg.user.username)
                temp_dict['发言者phone ：'] = str(result_msg.user.phone)
            except:
                pass
            temp_dict['媒体ID：'] = str(message_media_id)
            temp_dict['照片ID：'] = str(message_medis_photo_id)
            temp_dict['文件ID：'] = str(message_media_document_id)
            # print(result.stringify())
            # format_str = str(temp_dict['信息内容：']).strip().replace('\n','').replace('\r','')
            result.append(temp_dict)
            # result.append('\n')
            # print(msg)
        except Exception as e:
            print(e.args)
            pass
    print("===== 获取信息结束 ========")
    #     文件写入，格式为json
    with open('{file_local}'.format(file_local=file_local),'w',encoding='utf-8',) as f :
        json.dump(result,f,ensure_ascii=False,indent=2)
        # for re in result:
        # f.write(str(result))
def thread(loop,cli,query):  # 异步程序
    asyncio.set_event_loop(loop)
    # asyncio.ensure_future(task('sub thread',qurey1, aleikeji))
    # loop.run_forever()
    loop.run_until_complete(task(client,10, "E:\\111111.txt",1274378470))

def main():
    aleikeji = client.get_entity(PeerChannel(1274378470))
    anwang = client.get_entity(PeerChannel(1393167448))
    huichan = client.get_entity(PeerChannel(1336107536))
    threading.Thread(target=thread, args=(asyncio.get_event_loop(),anwang,qurey1 )).start()
    threading.Thread(target=thread, args=(asyncio.get_event_loop(),aleikeji,qurey1 )).start()

    try:
        # 同步代码开始
        future = asyncio.ensure_future(task(client,10, "E:\\222222.txt",1336107536))
        while not future.done():
            time.sleep(1)
        print('aleikeji done: %s' % future.result())
    except Exception as e :
        print(e.args)
    # with open('E:\\quer2.txt','w+',encoding='utf-8') as f:
    #     f.write(qurey2.get())
if __name__=='__main__':
    with client:
        client.loop.run_until_complete(main())