#!/usr/bin/env python
# -*- coding:utf-8 -*-
#@Time  : 2019/9/12 9:57
#@Author: weifulong
#@File  : test2.py
#coding=utf-8


from telethon import TelegramClient, sync,events




# Use your own values from my.telegram.org
# ==============    +8619965041445   ==================
# api_id = 1068342
# api_hash = '42a3c005195125361dd39c38f85946bb'
# client = TelegramClient('D:\pystation\\telegram\\telegram\\tel\\123.session', api_id, api_hash)
#=================    +8617344494726   ============
# api_id = 1061692
# api_hash = '10249070637ca3240d5553210fcee4d8'
# client = TelegramClient('F:\python_station\\telegram\\tel\8617344494726.session', api_id, api_hash)
# ==============   +8615303517524    ===================
# api_id = 1188540
# api_hash = 'f7fa2a4d485d3e1cb2177e74a2286589'
# client = TelegramClient('F:\python_station\\telegram\\tel\8615303517524.session', api_id, api_hash)

# ==============   +13323339652    ===================
api_id = 1195870
api_hash = '95c446cf9899c0ebf3de4ed3f5bb49c2'
client = TelegramClient('13323339652.session', api_id, api_hash)

group_result=[] #存放组名
channel_result=[] #存放频道名称
member_result=[] #存放普通用户
admin_result=[] #存放admin用户
creator_result=[] #存放创建者


async def main():
    #获取频道信息，名称，id  判断是否为channel   使用频道信息的 broadcast参数
        #print(str(dialo.stringify()).find('media=MessageMe
    async for dialog in client.iter_dialogs():
        print(dialog.name, 'has ID', dialog.id)
        # print(dialog.stringify())

    # ===============获取admin========
    from telethon.tl.types import ChannelParticipantsAdmins
    # async for user in client.iter_participants('暗网群',filter=ChannelParticipantsAdmins):
    # async for user in client.iter_participants('阿雷科技'):
    #     with open("E:\\1.txt",'a+',encoding='utf-8') as f:
    #         f.write(user.stringify())
    #         f.write('\n')
        # print(user.stringify())

# 获取频道全部信息
#     async for mess in client.iter_messages('阿雷科技'):
#         print(mess.stringify())
#
        # # 判断是否为channel   使用群组信息的 broadcast参数
        #print(str(dialo.stringify()).find('media=MessageMedia'))
        #        if dialo.message.id<100000:  #一般channel的id比较小目测为 小于十万100000
        #     print(dialo.name)
        # print("==================")

# =========获取用户id 1W+，同时可以获取用户内容==================
#     channel =await client.get_entity(PeerChannel(-1001172149960))  # 根据群组id获取群组对
#     responses =client.iter_participants(channel, aggressive=True)  # 获取群组所有用户信息
#     # print(responses)
#     async for respon in responses:
#         # print(respon.id)
#         with open("E:\\user_result.txt",'a+',encoding='utf-8') as f :
#             f.write(respon.stringify())
#             f.write('\n')
# ================自动添加去群组====================
#     from telethon.tl.functions.messages import ImportChatInviteRequest
#     updates = await client(ImportChatInviteRequest('OK96uxc9H4zE36GntvPx3g'))
#     print(updates.stringfy())
# =======================进入、离开群组获取信息============
        # @client.on(events.ChatAction)
        #     async def handle(event):
        #         if event.user_left or event.user_joined:
        #             print('1',await event.get_user())

# ==================添加===========
# from telethon.sync import TelegramClient
# from telethon import functions, types
#
# with TelegramClient(name, api_id, api_hash) as client:
#     result = client(functions.channels.GetFullChannelRequest(
#         channel='username'
#     ))
#     print(result.stringify())

with client:
    client.loop.run_until_complete(main())