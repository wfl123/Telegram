#!/usr/bin/env python
# -*- coding:utf-8 -*-
#@Time  : 2019/9/14 9:04
#@Author: weifulong
#@File  : thread111.py

import time
import asyncio
import threading

async def task(c, i):
    for _ in range(i):
        print(c)
        await asyncio.sleep(1)
    return i

def thread(loop):  # 异步程序
    asyncio.set_event_loop(loop)
    # asyncio.ensure_future(task('sub thread', 10))
    # loop.run_forever()
    loop.run_until_complete(task('sub thread', 10))

def main():
    threading.Thread(target=thread, args=(asyncio.get_event_loop(), )).start()

    # 同步代码开始
    future = asyncio.ensure_future(task('main thread', 5))
    while not future.done():
        time.sleep(1)
    print('main done: %s' % future.result())


if __name__ == '__main__':
    main()